# frontend/engine  (browser-side scraping pipeline)

Eta backend na, extension er bhitore browser e cholbe.

## Decision (V1): engine side panel er bhitore cholbe

`run-controller.js` shorashori `engine/index.js` import kore, kono message passing nai.
Trade-off: run cholar shomoy user side panel bondho korle ba browser bondho korle run mere jay, resume hoy na.
Pore dorkar hole `run-persistence.js` diye "last complete keyword theke resume" jog kora jabe (run-manager e `onKeywordDone` hook ache).
Offscreen / service worker e nite hole shudhu `run-controller.js` ar `index.js` er transport bodlabe, baki file gulo same thakbe.

## Kon file ki (status)

| File                   | Status | Kaj                                                                 |
| ---------------------- | ------ | ------------------------------------------------------------------- |
| index.js               | done   | run-manager + keyword-pipeline + results-store jora dey             |
| run-manager.js         | done   | State machine, keyword queue (ekta ekta kore), pause/resume/stop, error isolation, row batching, progress/stats. Test: `node --test frontend/engine/run-manager.test.mjs` |
| keyword-pipeline.js    | stub   | Ekta keyword er poora kaj. Ekhon "Maps pipeline is not connected yet." throw kore |
| maps-navigator.js      | todo   | Google Maps tab khola, search kora, load wait kora                  |
| maps-extractor.js      | todo   | Result list scroll + card theke data                                |
| dedupe.js              | todo   | Identity (placeId > domain > phone > name+address) + Master Lead Set |
| website-enricher.js    | todo   | Ekta website ekbar: homepage quick scan, contact page discovery     |
| contact-finder.js      | todo   | Email / social link khuje ber kora                                  |
| validator.js           | todo   | Basic validation (email format, phone, url)                         |
| scoring.js             | todo   | Explainable lead score (signal list soho)                           |
| filters-apply.js       | todo   | Pre-run ar post-run filter apply                                    |
| exporter.js            | todo   | CSV / Excel file toiri ar download                                  |
| run-persistence.js     | later  | Run state chrome.storage e save, resume                             |

## Data flow

    UI Start -> run-controller.start() -> engine.start(config, report)
             -> run-manager: keyword loop (ekta ekta kore)
             -> keyword-pipeline.processKeyword(keyword, ctx)
                  ctx.setStage / setCurrent / progress / addStats  -> report() -> UI progress card
                  ctx.addRows([...])                                -> results-store.addRows (20 ta kore batch)
             -> shesh: report({status:'completed'}) + results-store.setSummary(...)

`ctx` er poora list: `keyword-pipeline.js` er upore comment.

## Niyom (pipeline file gulo likhar shomoy)

1. Prottek chhoto dhapey `await ctx.checkpoint()`. Na dile Pause/Stop kaj korbe na.
2. `try/catch` e `RunStopped` dhorle abar throw koro (`isStopped(err)` from run-manager.js).
3. Fetch / timeout e `ctx.signal` dao, Stop chaple cancel hobe.
4. Ekta website fail korle keyword fail korio na, oi lead e `ERROR` status boshao.
5. Row `id` unique + stable. Shape: `services/results-store.js` er upore.

## Manifest permission (jokhon lagbe, tokhon jog hobe)

`maps-navigator.js` likhar shomoy root `manifest.json` e:

- `"scripting"` permission
- `"host_permissions": ["https://www.google.com/maps/*"]`
- Website visit er jonno pore broad host permission (`https://*/*`, `http://*/*`)

`tabs` permission lagbe na (tab create/update ar executeScript host permission diyei hoy).
Boro result er jonno pore `unlimitedStorage` ba IndexedDB.

## Validate korte hobe (POC)

Maps tab jodi background tab e thake (user onno tab e chole gele), Chrome timer throttle kore ar scroll/lazy-load atke jete pare.
Auto-scroll POC te dekhte hobe Maps tab visible thakte hobe kina (dedicated window lagte pare).
