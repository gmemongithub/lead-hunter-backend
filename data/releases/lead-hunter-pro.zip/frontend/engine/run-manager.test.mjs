// Chalate: node --test frontend/engine/run-manager.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import { createRunManager, isStopped, RunStopped } from './run-manager.js';

const tick = (ms = 5) => new Promise((r) => setTimeout(r, ms));

function setup(processKeyword, extra = {}) {
  const reports = [];
  const rowsCalls = [];
  const summaries = [];
  const results = { addRows: (r) => rowsCalls.push(r), setSummary: (s) => summaries.push(s) };
  const manager = createRunManager({ processKeyword, results, ...extra });
  const report = (p) => reports.push(p);
  return { manager, reports, rowsCalls, summaries, report };
}
const cfg = (...keywords) => ({ mode: 'bulk', keywords, fields: ['name'], filters: {} });
const row = (id) => ({ id: String(id), name: 'n' + id });

test('keywords run one at a time, in order', async () => {
  const log = [];
  const { manager, report } = setup(async (kw) => { log.push('start ' + kw); await tick(10); log.push('end ' + kw); });
  await manager.start(cfg('a', 'b', 'c'), report);
  assert.deepEqual(log, ['start a', 'end a', 'start b', 'end b', 'start c', 'end c']);
});

test('reports: running -> queue transitions -> completed with pct 100', async () => {
  const { manager, reports, report } = setup(async (kw, ctx) => { ctx.setStage('Maps'); ctx.setCurrent('biz ' + kw); ctx.progress(0.5); });
  await manager.start(cfg('a', 'b'), report);
  assert.equal(reports[0].status, 'running');
  assert.deepEqual(reports[0].queue.map((q) => q.status), ['pending', 'pending']);
  const last = reports.at(-1);
  assert.equal(last.status, 'completed');
  assert.equal(last.pct, 100);
  assert.deepEqual(last.queue.map((q) => q.status), ['complete', 'complete']);
  const pcts = reports.filter((r) => r.pct !== undefined).map((r) => r.pct);
  assert.deepEqual([...pcts].sort((x, y) => x - y), pcts, 'pct never goes backwards');
  assert.ok(reports.some((r) => r.keywordIndex === 1 && r.current === 'b'));
  assert.ok(reports.some((r) => r.stage === 'Maps') && reports.some((r) => r.current === 'biz a'));
  assert.ok(reports.some((r) => r.pct === 25), 'half of first of 2 keywords = 25%');
});

test('stats accumulate as deltas and summary becomes complete', async () => {
  const { manager, reports, summaries, report } = setup(async (kw, ctx) => { ctx.addStats({ discovered: 10, unique: 8, duplicates: 2, bogus: 5 }); });
  await manager.start(cfg('a', 'b'), report);
  const last = reports.at(-1);
  assert.equal(last.stats.discovered, 20);
  assert.equal(last.stats.unique, 16);
  assert.equal('bogus' in last.stats, false);
  assert.deepEqual(summaries.map((s) => s.status), ['partial', 'partial', 'complete']);
  assert.deepEqual(summaries.at(-1), { status: 'complete', keywords: 2, discovered: 20, duplicates: 4, unique: 16, websites: 0, emails: 0, social: 0, errors: 0 });
});

test('one failing keyword does not stop the rest (partial result)', async () => {
  const { manager, reports, summaries, report } = setup(async (kw, ctx) => { if (kw === 'b') throw new Error('boom'); ctx.addRows([row(kw)]); });
  await manager.start(cfg('a', 'b', 'c'), report);
  const last = reports.at(-1);
  assert.equal(last.status, 'completed');
  assert.deepEqual(last.queue.map((q) => q.status), ['complete', 'error', 'complete']);
  assert.equal(last.stats.errors, 1);
  assert.equal(summaries.at(-1).status, 'partial');
  assert.equal(summaries.at(-1).errors, 1);
});

test('all keywords failing rejects with the first error and leaves summary alone', async () => {
  const { manager, reports, summaries, report } = setup(async (kw) => { throw new Error('fail ' + kw); });
  await assert.rejects(manager.start(cfg('a', 'b'), report), /fail a/);
  assert.deepEqual(reports.at(-1).queue.map((q) => q.status), ['error', 'error']);
  assert.equal(summaries.length, 0);
});

test('pause blocks at checkpoint, resume continues', async () => {
  let reached = 0;
  let release;
  const gate = new Promise((r) => (release = r));
  const { manager, report } = setup(async (kw, ctx) => { await gate; await ctx.checkpoint(); reached += 1; });
  const p = manager.start(cfg('a'), report);
  await tick();
  manager.pause();
  release();
  await tick(20);
  assert.equal(reached, 0, 'stuck at checkpoint while paused');
  manager.resume();
  await p;
  assert.equal(reached, 1);
});

test('pause between keywords: next keyword does not start until resume', async () => {
  const started = [];
  const { manager, report } = setup(async (kw) => { started.push(kw); await tick(15); });
  const p = manager.start(cfg('a', 'b'), report);
  await tick(5);
  manager.pause();
  await tick(60);
  assert.deepEqual(started, ['a']);
  manager.resume();
  await p;
  assert.deepEqual(started, ['a', 'b']);
});

test('stop: start() resolves quietly, buffered rows are saved, no more reports, signal aborted', async () => {
  let signal;
  const { manager, reports, rowsCalls, report } = setup(async (kw, ctx) => {
    signal = ctx.signal;
    ctx.addRows([row(1), row(2), row(3)]);
    while (true) { await ctx.checkpoint(); await tick(5); }
  });
  const p = manager.start(cfg('a', 'b'), report);
  await tick(20);
  const before = reports.length;
  manager.stop();
  await p;
  await tick(20);
  assert.equal(reports.length, before, 'nothing reported after stop');
  assert.equal(signal.aborted, true);
  assert.deepEqual(rowsCalls.flat().map((r) => r.id), ['1', '2', '3']);
  assert.ok(!reports.some((r) => r.status === 'completed'));
});

test('stop while paused releases the run', async () => {
  const { manager, report } = setup(async (kw, ctx) => { await tick(5); await ctx.checkpoint(); await tick(5); await ctx.checkpoint(); });
  const p = manager.start(cfg('a'), report);
  manager.pause();
  await tick(30);
  manager.stop();
  await p;
});

test('checkpoint throws RunStopped that isStopped() recognises', async () => {
  let caught;
  const { manager, report } = setup(async (kw, ctx) => {
    try { while (true) { await ctx.checkpoint(); await tick(3); } } catch (e) { caught = e; throw e; }
  });
  const p = manager.start(cfg('a'), report);
  await tick(15);
  manager.stop();
  await p;
  assert.ok(caught instanceof RunStopped && isStopped(caught));
});

test('rows are batched (20 per flush) and the remainder is flushed at keyword end', async () => {
  const { manager, rowsCalls, report } = setup(async (kw, ctx) => { for (let i = 0; i < 45; i++) ctx.addRows([row(i)]); });
  await manager.start(cfg('a'), report);
  assert.deepEqual(rowsCalls.map((c) => c.length), [20, 20, 5]);
});

test('buffered rows are flushed when the run pauses', async () => {
  const { manager, rowsCalls, report } = setup(async (kw, ctx) => { ctx.addRows([row(1), row(2)]); await ctx.checkpoint(); });
  const p = manager.start(cfg('a'), report);
  manager.pause();
  await tick(20);
  assert.deepEqual(rowsCalls.flat().map((r) => r.id), ['1', '2']);
  manager.resume();
  await p;
});

test('second start while active is refused; a new run works after the first finishes', async () => {
  const { manager, report } = setup(async () => { await tick(20); });
  const p = manager.start(cfg('a'), report);
  await assert.rejects(manager.start(cfg('b'), report), /already active/);
  await p;
  await manager.start(cfg('b'), report);
});

test('a stopped run cannot leak reports into the next run', async () => {
  const seen = [];
  const { manager } = setup(async (kw, ctx) => { while (true) { await ctx.checkpoint(); await tick(3); } });
  const p1 = manager.start(cfg('a'), (r) => seen.push(['run1', r]));
  await tick(10);
  manager.stop();
  await p1;
  const m2 = createRunManager({ processKeyword: async () => {}, results: { addRows() {}, setSummary() {} } });
  await m2.start(cfg('x'), (r) => seen.push(['run2', r]));
  const run1AfterStop = seen.filter(([who], i) => who === 'run1' && i > seen.findIndex(([w]) => w === 'run2'));
  assert.equal(run1AfterStop.length, 0);
});

test('onKeywordDone hook gets index, keyword and status', async () => {
  const done = [];
  const { manager, report } = setup(async (kw) => { if (kw === 'b') throw new Error('x'); }, { onKeywordDone: (d) => done.push(d) });
  await manager.start(cfg('a', 'b', 'c'), report);
  assert.deepEqual(done, [{ index: 0, keyword: 'a', status: 'complete' }, { index: 1, keyword: 'b', status: 'error' }, { index: 2, keyword: 'c', status: 'complete' }]);
});

test('empty keyword list is rejected', async () => {
  const { manager, report } = setup(async () => {});
  await assert.rejects(manager.start({ keywords: [] }, report), /No keywords/);
});

test('resume: keywords in opts.skip are not run again; queue shows them complete from the start', async () => {
  const started = [];
  const { manager, reports, report } = setup(async (kw) => { started.push(kw); });
  await manager.start(cfg('a', 'b', 'c'), report, { skip: [0, 2] });
  assert.deepEqual(started, ['b']);
  assert.deepEqual(reports[0].queue.map((q) => q.status), ['complete', 'pending', 'complete']);
  assert.equal(reports[0].pct, 67);
  const last = reports.at(-1);
  assert.equal(last.status, 'completed');
  assert.equal(last.pct, 100);
  assert.deepEqual(last.queue.map((q) => q.status), ['complete', 'complete', 'complete']);
});

test('resume keeps the original keyword index and passes opts.job as ctx.job', async () => {
  const seen = [];
  const { manager, report } = setup(async (kw, ctx) => { seen.push({ kw, index: ctx.index, job: ctx.job }); });
  await manager.start(cfg('a', 'b'), report, { skip: [0], job: { id: 'job-1' } });
  assert.deepEqual(seen, [{ kw: 'b', index: 1, job: { id: 'job-1' } }]);
});

test('resume: when every remaining keyword fails the run still rejects', async () => {
  const { manager, report } = setup(async (kw) => { throw new Error('fail ' + kw); });
  await assert.rejects(manager.start(cfg('a', 'b'), report, { skip: [0] }), /fail b/);
});

test('resume: all keywords already complete finishes without running anything', async () => {
  let calls = 0;
  const { manager, reports, report } = setup(async () => { calls += 1; });
  await manager.start(cfg('a', 'b'), report, { skip: [0, 1] });
  assert.equal(calls, 0);
  assert.equal(reports.at(-1).status, 'completed');
});

test('a rejecting onKeywordDone hook does not stop the run', async () => {
  const started = [];
  const { manager, reports, report } = setup(async (kw) => { started.push(kw); }, { onKeywordDone: async () => { throw new Error('disk full'); } });
  await manager.start(cfg('a', 'b'), report);
  assert.deepEqual(started, ['a', 'b']);
  assert.equal(reports.at(-1).status, 'completed');
});

test('onKeywordDone is awaited before the next keyword starts', async () => {
  const log = [];
  const { manager, report } = setup(async (kw) => { log.push('run ' + kw); }, { onKeywordDone: async ({ keyword }) => { await tick(15); log.push('saved ' + keyword); } });
  await manager.start(cfg('a', 'b'), report);
  assert.deepEqual(log, ['run a', 'saved a', 'run b', 'saved b']);
});
